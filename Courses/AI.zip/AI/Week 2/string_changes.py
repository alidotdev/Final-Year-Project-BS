a = 'they'
b = 'the'


def compute(a , b , m , n):

    print("Checking characer of a: ", a[m-1] )
    print("Checking characer of a: ", b[n-1], '\n')
    if m == 0:
        return n
    elif n == 0:
        return m
    elif a[m -1 ] ==  b[n - 1]:
        return compute(a , b , m-1 , n-1)
    else:
        print("Calling Substitution")
        c1 = 1 + compute(a , b , m-1 , n-1)
        print("Calling deletion")
        c2 = 1 + compute(a , b , m-1 , n)
        print("Calling insertion")
        c3 = 1 + compute(a , b , m , n-1)

        return min(c1, c2 , c3)
    

print(compute(a , b , len(a), len(b)))
